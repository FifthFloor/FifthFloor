
Readme.txt - Blur Studio's generic readme file.  See other included
documentation or the blur web site for any further documentation/info.

Distribution / Licensing

The Plugin(s) and/or software downloaded with this readme file are 
Freeware and are not to be distributed as part of any bundle or 
package without prior approval from Blur Studio, Inc.  

Installation Instructions

3D STUDIO MAX PLUGINS:
Installation of the plugin(s) is the same as with any new plugin for 
3DS Max.  Copy the plugin DLLs into the directory where you currently 
have plugins, or create a new directory for them and set the path 
configuration within Max to point to that directory.  

DIGITAL FUSION PLUGINS:
Copy the plugin DLLs to Digital Fusion's Plugin directory

About Blur Studio and Contact Info

To contact the authors of the plugin(s) for 3DS Max with 
comments, bug reports, etc., please email us at BlurBeta@blur.com -- 
If you are expecting a response, please be patient.  We are very busy 
and will get back to you when we can.

Blur Studio is not in the business of software development.  We are 
a 3D computer animation house specializing in design and creation of 
cg visual effects for film, commercials, tv series, broadcast and games.  
The plugin(s) are created for use in house. We can neither guarantee 
nor provide support and updates to this software, but by contacting us 
through our email address, we will do what we can within the limits of 
our current production schedule.  The only testing this plugin has 
undergone is real world testing in our production environment running 
multi-processor machines in a networked environment.  For more info 
about Blur, you can check out our website at http://www.blur.com

-end-
